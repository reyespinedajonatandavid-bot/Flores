# ✅ Sorprende  a tu Novia con este Proyecto de  Flor Amarilla 🌻 | HTML CSS JS
### Video del tutorial: [https://youtu.be/ZSSOiJaMIk0](https://youtu.be/ZSSOiJaMIk0)

![image](https://github.com/user-attachments/assets/899d1b33-bc87-45f8-8cb9-e11cf992a9d6)
